﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRFramework.Model
{
    public class StatusMessage
    {
        public string Text { get; set; }
        public StatusMessageType MessageType { get; set; }

    }
}
